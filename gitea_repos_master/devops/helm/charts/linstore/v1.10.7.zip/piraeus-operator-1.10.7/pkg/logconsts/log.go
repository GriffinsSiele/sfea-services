package logconsts

const (
	INFO  = 1
	DEBUG = 2
)
